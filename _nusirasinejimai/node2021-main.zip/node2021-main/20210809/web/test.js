if (1===1)
    console.log("lygu");