function daugyba(){
    for (let x=1; x<=10; x++)
        console.log("2 * "+x+"\t="+(x*2) );
    

    console.log(x);
    
}


daugyba();