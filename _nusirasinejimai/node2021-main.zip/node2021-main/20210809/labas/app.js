function labas(name){
    console.log("Labas pasauli!\nMano vardas "+name);
}


labas("Gediminas");