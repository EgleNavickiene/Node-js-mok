console.log("Failas: user.js")
const vardas="Jonas";
const pavarde="Jonaitis";

module.exports={
    vardas, pavarde
};