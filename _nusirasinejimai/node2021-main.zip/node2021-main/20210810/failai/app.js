const fs=require('fs');

// fs.writeFileSync('tekstas.txt', 'Dar kazkokia informacija');

fs.appendFileSync('tekstas.txt','Kazkas prisijunge prie kompiuterio \n');