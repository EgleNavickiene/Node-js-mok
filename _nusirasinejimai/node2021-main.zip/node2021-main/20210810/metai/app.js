const {isKeliamieji, keliamieji} = require("./metai");


keliamieji(2020);
console.log(isKeliamieji(2020));

