
if (1===1){
    import  getUserSurname  from './user.js';
    console.log("Sveikas: "+getUserSurname("Jonas", "Jonaitis"));
}

