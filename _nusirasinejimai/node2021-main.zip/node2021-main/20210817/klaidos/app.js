//Prisidedame moduli ir jo eksportuota kintamaji issaugome i kintamaji svdiena
const svdiena=require('./svdiena'); 


console.log(svdiena(17));

//Norint kad būtų paleistas debugger'is reikia vykdyti komandą:
//node inspect app.js