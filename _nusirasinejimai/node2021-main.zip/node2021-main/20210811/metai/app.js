const {isKeliamieji, keliamieji} = require("./metai");
const chalk = require('chalk');

//console.log(process.argv);
let metai=process.argv[2];

keliamieji(metai);

