

function skaiciuoti(x){
   
    return i+ii;
}

let x=5;
let y=3;



console.log( skaiciuoti(x) );
console.log( x );
console.log( y );