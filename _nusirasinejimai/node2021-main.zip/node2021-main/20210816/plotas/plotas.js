const plotas=(n,m)=>{
   return n*m;
};
module.exports=plotas;