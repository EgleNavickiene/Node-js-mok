function  isvedimas() {
    let x=5;
    console.log("Is funkcijos");
}


console.log("Labas");
